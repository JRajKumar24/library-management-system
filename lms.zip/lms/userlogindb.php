<?php

include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST'){

$regno=$_POST['regno'];
$password=$_POST['password'];

$ans=mysqli_query($result,"select password from registration where regno=$regno");

$row=$ans->fetch_assoc();

$hash=$row['password'];

$pass=password_verify($password,$hash);

if($pass){
    header("location:userpage.php");
}
else{
    echo "not verified";
}

}



?>