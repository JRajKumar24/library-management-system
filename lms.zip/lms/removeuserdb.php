<?php
include('config.php'); 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data
    $regno = trim($_POST['regno']);
    $dept = trim($_POST['dept']);

    // Checing if the user exists in the registration table
    $checkQuery = "SELECT * FROM registration WHERE regno = '$regno' AND dept = '$dept'";
    $checkResult = mysqli_query($result, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        // User exists,  delete
        $deleteQuery = "DELETE FROM registration WHERE regno = '$regno' AND dept = '$dept'";
        $deleteResult = mysqli_query($result, $deleteQuery);

        if ($deleteResult) {
            echo "<script>alert('User removed successfully.'); window.location.href = 'adminpage.php';</script>";
        } else {
            echo "<script>alert('Failed to remove the user.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('No user found with the provided registration number and department.'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Invalid request method.'); window.history.back();</script>";
}
?>