<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column; 
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .title-container {
            background-color: black; 
            width: 100%;
            padding: 20px 0;
            text-align: center;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 1;
        }

        h1 {
            color: #fff;
            font-size: 3em;
            text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.5);
            margin: 0;
        }

        .container {
            background-color: rgba(0, 0, 0, 0.8); /* Dark background */
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.5);
            width: 400px;
            text-align: center;
            margin-top: 80px; 
        }

        h2 {
            color: whitesmoke;
            margin-bottom: 25px;
            font-size: 2em;
            font-weight: 600;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: white; 
            text-align: left;
            font-size: 1.1em;
        }

        .form-control {
            width: 100%;
            padding: 14px;
            margin-bottom: 25px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1.1em;
            color: #333;
            background-color: #f9f9f9;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            box-sizing: border-box; /* Ensure padding and border are included in the width */
        }

        button {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 16px 32px;
            border-radius: 8px;
            font-size: 1.2em;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%; /* Full width button */
            font-weight: bold;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        button:hover {
            background-color: #cc0000;
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        /* Error Message Styling */
        .error {
            color: #ff4d4d;
            font-size: 0.9em;
            margin-top: -15px;
            margin-bottom: 15px;
            text-align: left;
            display: none; /* Hidden by default */
        }
    </style>
</head>
<body>
    <!-- Full-screen background for the title -->
    <div class="title-container">
        <h1>Library Management System</h1>
    </div>

    <!-- Main Form Container -->
    <div class="container">
        <h2>Remove User</h2>
        <form id="removeUserForm" action="removeuserdb.php" method="POST" onsubmit="return validateForm()">
            <label for="regno">Enter Registration Number:</label>
            <input type="text" id="regno" name="regno" class="form-control" required oninput="validateRegNo()">
            <div id="regnoError" class="error">Registration number must be exactly 12 digits.</div>

            <label for="dept">Select Department:</label>
            <select id="dept" name="dept" class="form-control" required>
                <option value="" disabled selected>Select Department</option>
                <option value="CSE">CSE</option>
                <option value="ECE">ECE</option>
                <option value="EEE">EEE</option>
                <option value="MECH">MECH</option>
                <option value="CIVIL">CIVIL</option>
            </select>

            <button type="submit">Remove</button>
        </form>
    </div>

    <script>
        // Dynamic validation for registration number
        function validateRegNo() {
            const regnoInput = document.getElementById('regno');
            const regnoError = document.getElementById('regnoError');
            const regnoValue = regnoInput.value.trim();

            if (regnoValue.length !== 12 || isNaN(regnoValue)) {
                regnoError.style.display = 'block';
                regnoInput.style.borderColor = '#ff4d4d';
                return false;
            } else {
                regnoError.style.display = 'none';
                regnoInput.style.borderColor = '#ddd';
                return true;
            }
        }

        // Form submission validation
        function validateForm() {
            return validateRegNo();
        }
    </script>
</body>
</html>