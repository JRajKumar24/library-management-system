<!DOCTYPE html>
<html>
<head>
    <style>

        .popup {
            position: fixed;
            top: 0; /* Position at the top */
            left: 40%;
            background: green;
            color: white;
            padding: 10px 30px;
            border-radius: 0 0 10px 10px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            animation: slideDown 0.5s ease-out; /* Slide-down animation */
        }

        /* Slide-down animation */
        @keyframes slideDown {
            from {
                top: -50px;
            }
            to {
                top: 0;
            }
        }

        /* Fade-out animation */
        @keyframes fadeOut {
            from {
                opacity: 1;
            }
            to {
                opacity: 0;
            }
        }

        h1{
            background-color:darkgray;
        }
        table{
            background-color:darkgray;
            justify-content: space-between;border-radius: 15px; 
            padding:80px;
        }
        td {
           
            text-align: center; 
        }
        a{
            text-decoration:none;color:black;
            background-color:steelblue;padding:12px;border-radius:15px;
        }
        a:hover{
            background-color:green;color:white;
            box-shadow: 0 8px 20px green;
        }
        #one:hover{
            background-color:crimson;color:white;
            box-shadow: 0 8px 20px crimson;
        }
    </style>
</head>
<body>
    <!-- Popup -->
    <div id="popup" class="popup">
        Logged in successfully!
    </div>

   <center><h1>LIBRARY MANAGEMENT SYSTEM</h1></center>

   <a href="userlogin.php" id="one" style="float:right;margin-right:15px;">Logout</a>

    <br><br><br><br>
    <center>
    <table>
        <tr>
            <td><a class="options" href="booksretrieve.php">Booklist</a></td>
        </tr>
        <tr>
            <td class="options" style="padding-top:100px;"><a href="#" >borrowhistory</a></td>
        </tr>
    </table>
    </center>


    <script>
        // Show the popup when the page loads
        window.onload = function() {
            const popup = document.getElementById('popup');
            popup.style.display = 'block'; // Show the popup

            // Hide the popup after 2 seconds with a fade-out effect
            setTimeout(function() {
                popup.style.animation = 'fadeOut 0.5s ease-out'; // Apply fade-out animation
                setTimeout(function() {
                    popup.style.display = 'none'; // Hide the popup after animation
                }, 500); // Match the duration of the fade-out animation
            }, 1500); // Show the popup for 1.5 seconds
        };
    </script>
</body>
</html>