<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Library Management System</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #007bff, #00bfff);
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }

    header {
      background: linear-gradient(135deg, #0056b3, #007bff);
      color: white;
      width: 100%;
      padding: 20px 0;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      margin-bottom: 20px;
    }

    header h1 {
      margin: 0;
      font-size: 2.5rem;
      font-weight: 600;
    }

    .container {
      background-color: #ffffff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      width: 400px;
      text-align: center;
      border: 2px solid #007bff;
    }

    .form-heading {
      font-size: 1.8rem;
      font-weight: 600;
      color: #007bff;
      margin-bottom: 20px;
    }

    label {
      display: block;
      text-align: left;
      margin-bottom: 8px;
      color: #495057;
      font-weight: 600;
      font-size: 14px;
    }

    input[type="text"],
    input[type="date"] {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 2px solid #ced4da;
      border-radius: 8px;
      font-size: 16px;
      transition: border-color 0.3s ease;
      background-color: #f8f9fa;
    }

    input[type="text"]:focus,
    input[type="date"]:focus {
      border-color: #007bff;
      outline: none;
      background-color: #ffffff;
    }

    button {
      background: linear-gradient(135deg, #28a745, #218838);
      color: white;
      padding: 14px 20px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      width: 100%;
      transition: background 0.3s ease;
    }

    button:hover {
      background: linear-gradient(135deg, #218838, #1e7e34);
    }

    .error {
      color: #dc3545;
      font-size: 14px;
      text-align: left;
      margin-top: -10px;
      margin-bottom: 10px;
      display: none;
    }

    .success {
      color: #28a745;
      font-size: 16px;
      font-weight: 600;
      margin-top: 20px;
      display: none;
    }
  </style>
</head>
<body>
  <header>
    <h1>Library Management System</h1>
  </header>

  <div class="container">
    <div class="form-heading">Issue Book</div>
    <form id="issueForm" action="issuebookdb.php" method="POST"onsubmit="return validateForm()">
      <div>
        <label for="regno">Registration Number:</label>
        <input
          type="text"
          id="regno"
          name="regno"
          placeholder="Enter 12-digit registration number"
          maxlength="12"
          required
          oninput="validateRegNo(this)"
        />
        <div class="error" id="regnoError">Registration number must be exactly 12 digits and contain only numbers.</div>
      </div>

      <div>
        <label for="bookname">Book Name:</label>
        <input
          type="text"
          id="bookname"
          name="bookname"
          placeholder="Enter book name"
          maxlength="255"
          required
          oninput="validateBookName(this)"
        />
        <div class="error" id="booknameError">Book name is required.</div>
      </div>

      <div>
        <label for="issuedate">Issue Date:</label>
        <input
          type="date"
          id="issuedate"
          name="issuedate"
          required
          oninput="validateIssueDate(this)"
        />
        <div class="error" id="issuedateError">Issue date is required.</div>
      </div>

      <button type="submit">Issue Book</button>
      <div class="success" id="successMessage">Book issued successfully!</div>
    </form>
  </div>

  <script>
    // Real-time validation functions
    function validateRegNo(input) {
      const regnoError = document.getElementById("regnoError");
      if (input.value.length !== 12 || !/^\d+$/.test(input.value)) {
        regnoError.textContent = "Registration number must be exactly 12 digits and contain only numbers.";
        regnoError.style.display = "block";
        input.setCustomValidity("Invalid");
      } else {
        regnoError.style.display = "none";
        input.setCustomValidity("");
      }
    }

    function validateBookName(input) {
      const booknameError = document.getElementById("booknameError");
      if (input.value.trim() === "") {
        booknameError.textContent = "Book name is required.";
        booknameError.style.display = "block";
        input.setCustomValidity("Invalid");
      } else {
        booknameError.style.display = "none";
        input.setCustomValidity("");
      }
    }

    function validateIssueDate(input) {
      const issuedateError = document.getElementById("issuedateError");
      if (input.value === "") {
        issuedateError.textContent = "Issue date is required.";
        issuedateError.style.display = "block";
        input.setCustomValidity("Invalid");
      } else {
        issuedateError.style.display = "none";
        input.setCustomValidity("");
      }
    }

    // Final validation on form submission
    function validateForm() {
      const regno = document.getElementById("regno");
      const bookname = document.getElementById("bookname");
      const issuedate = document.getElementById("issuedate");

      // Trigger validation for all fields
      validateRegNo(regno);
      validateBookName(bookname);
      validateIssueDate(issuedate);

      // Check if all fields are valid
      if (regno.checkValidity() && bookname.checkValidity() && issuedate.checkValidity()) {
        document.getElementById("successMessage").style.display = "block";
        setTimeout(() => {
          document.getElementById("successMessage").style.display = "none";
        }, 3000); // Hide success message after 3 seconds
        return true; // Allow form submission
      } else {
        return false; // Prevent form submission
      }
    }
  </script>
</body>
</html>