
<?php

include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST'){

    $bookName = $_POST['bookname'];
    $author = $_POST['author'];
    $noOfPages = $_POST['pages'];
    $yearOfPublish = $_POST['year'];
    $noOfCopies = $_POST['copies'];

    $ans=mysqli_query($result,"insert into books values('','$bookName ','$author','$noOfPages','$yearOfPublish','$noOfCopies')");
    if($ans){
        echo "<script>
        alert('Book added successfully!');
        window.location.href = 'adminpage.php';
      </script>";
        
    }
    else{
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }

}


?>