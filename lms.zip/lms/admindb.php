

<?php

include ("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $a = $_POST['name'];
    $b = $_POST['password'];
    
    $ans=mysqli_query($result,"select name,password from admin where id=1");

    $row=$ans->fetch_assoc();
    
    $admin_name=$row['name'];
    $pass=$row['password'];
    
    if($admin_name==$a && $pass==$b){
        header("Location: adminpage.php");
    }
    else{
        echo  "invalid username or password";
    }
 
} else {
    echo "Form not submitted.";
}




?>