<!DOCTYPE html>
<html>

<head>
    <title>View Returned Books</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #6a11cb;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .no-data {
            text-align: center;
            color: #777;
            padding: 20px;
        }
    </style>
</head>

<body>
    <h1>Returned Books</h1>

    <?php
    include('config.php'); // Include database connection

    // Fetch all records from the returnbook table
    $query = "SELECT * FROM returnbook";
    $resul = mysqli_query($result, $query);

    if (mysqli_num_rows($resul) > 0) {
        // Display the records in a table
        echo '<table>
                <tr>
                    <th>ID</th>
                    <th>Registration Number</th>
                    <th>Book Name</th>
                    <th>Return Date</th>
                    <th>Overdue Fine</th>
                    <th>Book Damage Fine</th>
                    <th>Total Fine</th>
                </tr>';

        while ($row = mysqli_fetch_assoc($resul)) {
            echo '<tr>
                    <td>' . $row['id'] . '</td>
                    <td>' . $row['regno'] . '</td>
                    <td>' . $row['bookname'] . '</td>
                    <td>' . $row['returndate'] . '</td>
                    <td>' . $row['overduefine'] . '</td>
                    <td>' . $row['bookdamagefine'] . '</td>
                    <td>' . $row['totalfine'] . '</td>
                  </tr>';
        }

        echo '</table>';
    } else {
        // No records found
        echo '<div class="no-data">No records found in the returnbook table.</div>';
    }

    // Close the database connection
    mysqli_close($resul);
    ?>
</body>

</html>