<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .container {
            text-align: center;
            max-width: 800px;
            width: 100%;
            padding: 20px;
        }

        h1 {
            font-size: 2.5rem;
            color: #fff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            margin-bottom: 20px;
        }

        form {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
        }

        form table {
            width: 100%;
        }

        form table td {
            padding: 10px;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        input[type="submit"] {
            background-color: #667eea;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 7px;
            font-size: 1rem;
            cursor: pointer;
            float: right;
        }

        input[type="submit"]:hover {
            background-color: #d15a9e;
            transform: scale(1.1);
        }

        .form-header {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .error {
            color: red;
            font-size: 0.9rem;
            margin-top: 5px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>LIBRARY MANAGEMENT SYSTEM</h1>
        <form id="bookForm" method="POST" action="insertbookdb.php" onsubmit="return validateForm()">
            <div class="form-header">Enter Book Details</div>
            <table>
                <tr>
                    <td>Book Name</td>
                    <td>
                        <input type="text" id="bookName" name="bookname" oninput="validateBookName()" required>
                        <div class="error" id="bookNameError">Book name must contain only letters or letters with digits.</div>
                    </td>
                </tr>
                <tr>
                    <td>Author</td>
                    <td>
                        <input type="text" id="author" name="author" oninput="validateAuthor()" required>
                        <div class="error" id="authorError">Author name must contain only letters.</div>
                    </td>
                </tr>
                <tr>
                    <td>No. of Pages</td>
                    <td>
                        <input type="text" id="pages" name="pages" oninput="validatePages()" required>
                        <div class="error" id="pagesError">Number of pages must be digits only.</div>
                    </td>
                </tr>
                <tr>
                    <td>Year of Publish</td>
                    <td>
                        <input type="text" id="year" name="year" oninput="validateYear()" required>
                        <div class="error" id="yearError">Please enter a valid year.</div>
                    </td>
                </tr>
                <tr>
                    <td>No. of Copies</td>
                    <td>
                        <input type="text" id="copies" name="copies" oninput="validateCopies()" required>
                        <div class="error" id="copiesError">Number of copies must be digits only.</div>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Submit">
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <script>
        // Function to validate Book Name
        function validateBookName() {
            const bookName = document.getElementById('bookName').value.trim();
            const bookNameError = document.getElementById('bookNameError');
            if (!/^[A-Za-z0-9 ]+$/.test(bookName)) {
                bookNameError.style.display = 'block';
                return false;
            } else {
                bookNameError.style.display = 'none';
                return true;
            }
        }

        // Function to validate Author
        function validateAuthor() {
            const author = document.getElementById('author').value.trim();
            const authorError = document.getElementById('authorError');
            if (!/^[A-Za-z ]+$/.test(author)) {
                authorError.style.display = 'block';
                return false;
            } else {
                authorError.style.display = 'none';
                return true;
            }
        }

        // Function to validate No. of Pages
        function validatePages() {
            const pages = document.getElementById('pages').value.trim();
            const pagesError = document.getElementById('pagesError');
            if (!/^\d+$/.test(pages)) {
                pagesError.style.display = 'block';
                return false;
            } else {
                pagesError.style.display = 'none';
                return true;
            }
        }

        // Function to validate Year of Publish
        function validateYear() {
            const year = document.getElementById('year').value.trim();
            const yearError = document.getElementById('yearError');
            const currentYear = new Date().getFullYear();
            if (!/^\d{4}$/.test(year) || year < 1000 || year > currentYear) {
                yearError.style.display = 'block';
                return false;
            } else {
                yearError.style.display = 'none';
                return true;
            }
        }

        // Function to validate No. of Copies
        function validateCopies() {
            const copies = document.getElementById('copies').value.trim();
            const copiesError = document.getElementById('copiesError');
            if (!/^\d+$/.test(copies)) {
                copiesError.style.display = 'block';
                return false;
            } else {
                copiesError.style.display = 'none';
                return true;
            }
        }

        // Function to validate the entire form
        function validateForm() {
            const isBookNameValid = validateBookName();
            const isAuthorValid = validateAuthor();
            const isPagesValid = validatePages();
            const isYearValid = validateYear();
            const isCopiesValid = validateCopies();

            // If all validations pass, return true (allow form submission)
            if (isBookNameValid && isAuthorValid && isPagesValid && isYearValid && isCopiesValid) {
                return true;
            } else {
                alert("Please correct the errors before submitting.");
                return false; // Prevent form submission
            }
        }
    </script>
</body>
</html>