
<?php
include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST'){

    $name=$_POST['name'];
    $regno=$_POST['regno'];
    $dob=$_POST['dob'];
    $dept=$_POST['dept'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);


    $query=mysqli_query($result,"insert into registration values('$name','$regno','$dob','$dept','$email','$hashed_password')");

    if($query){
        header("location:userlogin.php");
    }
    else{
        echo"not registered";
    }
}

?>