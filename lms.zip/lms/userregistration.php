<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <style>
        
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
            position: relative;
            font-family: 'Arial', sans-serif;
        }

       
        img {
            height: 100vh;
            width: 100vw;
            object-fit: cover;
            opacity: 0.8;
            position: absolute;
            top: 0;
            left: 0;
            z-index: -1;
        }

       
        .title {
            text-align: center;
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.6);
            padding: 10px 20px;
            border-radius: 10px;
        }

        .nav {
            float: right;
            margin: 20px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 0 5px;
            border-radius: 5px;
            background-color: rgba(0, 0, 0, 0.5);
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .nav a:hover {
            background-color: rgba(0, 0, 0, 0.8);
            transform: translateY(-2px);
        }

       
        form {
            position: absolute;
            top: 50%; 
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: cornflowerblue;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 600px; 
            text-align: center;
        }

        form h1 {
            color: white;
            background-color: rgba(0, 0, 0, 0.7);
            padding: 10px 20px;
            border-radius: 10px;
            margin-top: 0;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .form-columns {
            display: flex;
            justify-content: space-between;
        }

        .form-column {
            width: 48%;
        }

        form table {
            width: 100%;
        }

        form td {
            padding: 10px;
            min-height: 70px; 
        }

        form label {
            color: white;
            font-weight: bold;
        }

        form input,
        form select {
            width: 100%;
            padding: 8px;
            border: none;
            border-radius: 5px;
            margin-top: 5px;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        form input:focus,
        form select:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(255, 255, 255, 0.5);
        }

        .error {
            color: red;
            font-size: 0.8em;
            margin-top: 5px;
            display: none;
        }

        button {
            padding: 12px 20px; 
            border: none;
            border-radius: 5px;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
            margin-top: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            float: right; 
        }

        button:hover {
            background: linear-gradient(135deg, #2575fc, #6a11cb);
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
        }

        button:active {
            transform: translateY(0);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>

    
    <img src="regbackground.jpg" alt="Library Image"><br>

    
    <div class="title">Library Management System</div>

    
    <div class="nav">
        <a href="homepage.php" style="padding-right:15px;">Home</a>
    </div>

   
    <form action="registrationdb.php" onsubmit="return validateForm()" method="POST">
        <h1>Registration Form</h1>
        <div class="form-columns">
            
            <div class="form-column">
                <table>
                    <tr>
                        <td><label>Name</label></td>
                        <td>
                            <input type="text" id="name" placeholder="Enter your name" oninput="validateName()" name="name" required>
                            <div id="name-error" class="error">Name must contain only letters.</div>
                        </td>
                    </tr>
                    <tr>
                        <td><label>Register No</label></td>
                        <td>
                            <input type="text" id="regno" placeholder="Enter your register number" oninput="validateRegNo()" name="regno" required>
                            <div id="regno-error" class="error">Register number must be 12 digits.</div>
                        </td>
                    </tr>
                    <tr>
                        <td><label>DOB</label></td>
                        <td><input type="date" id="dob" name="dob" required></td>
                    </tr>
                </table>
            </div>

            <div class="form-column">
                <table>
                    <tr>
                        <td><label>Dept</label></td>
                        <td>
                            <select name="dept" required>
                                <option selected disabled>Select Department</option>
                                <option>CSE</option>
                                <option>ECE</option>
                                <option>EEE</option>
                                <option>MECH</option>
                                <option>CIVIL</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label>Email</label></td>
                        <td>
                            <input type="email" id="email" name="email"placeholder="Enter your email" oninput="validateEmail()" required>
                            <div id="email-error" class="error">Invalid email format.</div>
                        </td>
                    </tr>
                    <tr>
                        <td><label>Password</label></td>
                        <td>
                            <input type="password" id="password" name="password"placeholder="Enter your password" oninput="validatePassword()" required>
                            <div id="password-error" class="error">Password must be 8-16 characters.</div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <button type="submit">Register</button>
    </form>

    <script>
        
        function validateName() {
            const name = document.getElementById('name').value;
            const nameError = document.getElementById('name-error');
            const regex = /^[A-Za-z\s]+$/;

            if (!regex.test(name)) {
                nameError.style.display = 'block';
                return false;
            } else {
                nameError.style.display = 'none';
                return true;
            }
        }

        //  Register No (exactly 12 digits)
        function validateRegNo() {
            const regno = document.getElementById('regno').value;
            const regnoError = document.getElementById('regno-error');
            const regex = /^\d{12}$/;

            if (!regex.test(regno)) {
                regnoError.style.display = 'block';
                return false;
            } else {
                regnoError.style.display = 'none';
                return true;
            }
        }

        // Validate Email (standard email format)
        function validateEmail() {
            const email = document.getElementById('email').value;
            const emailError = document.getElementById('email-error');
            const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!regex.test(email)) {
                emailError.style.display = 'block';
                return false;
            } else {
                emailError.style.display = 'none';
                return true;
            }
        }

        // Validate Password (8-16 characters, one uppercase, lowercase, numbers, special character)
        function validatePassword() {
            const password = document.getElementById('password').value;
            const passwordError = document.getElementById('password-error');
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;

            if (!regex.test(password)) {
                passwordError.style.display = 'block';
                return false;
            } else {
                passwordError.style.display = 'none';
                return true;
            }
        }

        // Validate Form Before Submission
        function validateForm() {
            const isNameValid = validateName();
            const isRegNoValid = validateRegNo();
            const isEmailValid = validateEmail();
            const isPasswordValid = validatePassword();

            // If all validations pass, allow form submission
            if (isNameValid && isRegNoValid && isEmailValid && isPasswordValid) {
                return true; // Allow form submission
            } else {
                return false; // Prevent form submission
            }
        }
    </script>
</body>
</html>