<?php
include('config.php'); // Include database connection

// Fetch form data
$regno = $_POST['regno'];
$bookname = $_POST['bookname'];
$returndate = $_POST['returndate'];
$overduefine = $_POST['overduefine'];
$bookdamagefine = $_POST['bookdamagefine'];
$totalfine = $_POST['totalfine'];

// Insert data into the returnbook table
$query = "INSERT INTO returnbook 
          VALUES ('','$regno', '$bookname', '$returndate', '$overduefine', '$bookdamagefine', '$totalfine')";

if (mysqli_query($result, $query)) {
    // If the book is returned successfully, increment no_of_copies in the books table
    $updateQuery = "UPDATE books SET no_of_copies = no_of_copies + 1 WHERE bookname = '$bookname'";
    
    if (mysqli_query($result, $updateQuery)) {
        echo 'success';
    } else {
        echo 'Error updating book copies: ' . mysqli_error($result); // Debug SQL errors
    }
} else {
    echo 'Error: ' . mysqli_error($result); // Debug SQL errors
}
?>