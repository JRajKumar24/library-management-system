<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <style>
    
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: black;
            color: white;
            height: 100vh;
            overflow: hidden; 
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
        }

        .image-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1; 
        }

        .image-container img {
            width: 100%;
            height: 100%;
            object-fit: cover; 
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6); /* Dark */
        }

        h1 {
            font-size: 3.5rem;
            font-weight: bold;
            color: white;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.8);
            margin-bottom: 20px;
            animation: fadeIn 2s ease-in-out; /* Fade-in animation */
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(-20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .links {
            display: flex;
            gap: 25px;
            animation: slideUp 1.5s ease-in-out; /* Slide-up animation */
        }

        @keyframes slideUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .links button {
            padding: 15px 30px;
            font-size: 1.2rem;
            font-weight: bold;
            background: linear-gradient(45deg, #ff4b2b, #ff416c);
            color: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(255, 65, 108, 0.4);
        }

        .links button:hover {
            background: linear-gradient(45deg, #41e3ff, #2bc6ff);
            transform: scale(1.1);
            box-shadow: 0 8px 20px rgba(65, 227, 255, 0.6);
        }

        .links button a {
            color: inherit;
            text-decoration: none;
            display: block;
        }
    </style>
</head>
<body>

    <h1>Library Management System</h1>

    <div class="image-container">
        <img src="homeimage.jpg" alt="Library Background">
        <div class="overlay"></div>
    </div>

    <div class="links">
        <button><a href="userlogin.php">User Login</a></button>
        <button><a href="adminlogin.php">Admin Login</a></button>
        <button><a href="userregistration.php">New User</a></button>
    </div>

</body>
</html>