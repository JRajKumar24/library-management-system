<?php
include 'config.php'; // Include database connection

// Check if a search query is provided
$search = isset($_GET['search']) ? $_GET['search'] : '';
$search_condition = $search ? "AND (r.username LIKE '%$search%' OR i.regno LIKE '%$search%' OR i.bookname LIKE '%$search%')" : '';

// Fetch currently issued books (not returned)
$query = "SELECT i.issueid, i.regno, r.username, i.bookname, i.issuedate, 
                 b.author, b.no_of_pages, b.year_of_publish
          FROM issue i
          JOIN registration r ON i.regno = r.regno
          JOIN books b ON i.bookname = b.book_name
          WHERE NOT EXISTS (
              SELECT 1 FROM returnbook rb 
              WHERE rb.regno = i.regno 
              AND rb.bookname = i.bookname
              AND rb.returndate >= i.issuedate
              AND (
                  NOT EXISTS (
                      SELECT 1 FROM issue i2 
                      WHERE i2.regno = i.regno 
                      AND i2.bookname = i.bookname 
                      AND i2.issuedate > i.issuedate
                  )
                  OR rb.returndate < (
                      SELECT MIN(issuedate) FROM issue i3 
                      WHERE i3.regno = i.regno 
                      AND i3.bookname = i.bookname 
                      AND i3.issuedate > i.issuedate
                  )
              )
          ) $search_condition
          ORDER BY i.issuedate DESC";

$resul = mysqli_query($result, $query);

// Count total unreturned books
$count_query = "SELECT COUNT(*) as total FROM issue i
                WHERE NOT EXISTS (
                    SELECT 1 FROM returnbook rb 
                    WHERE rb.regno = i.regno 
                    AND rb.bookname = i.bookname
                    AND rb.returndate >= i.issuedate
                    AND (
                        NOT EXISTS (
                            SELECT 1 FROM issue i2 
                            WHERE i2.regno = i.regno 
                            AND i2.bookname = i.bookname 
                            AND i2.issuedate > i.issuedate
                        )
                        OR rb.returndate < (
                            SELECT MIN(issuedate) FROM issue i3 
                            WHERE i3.regno = i.regno 
                            AND i3.bookname = i.bookname 
                            AND i3.issuedate > i.issuedate
                        )
                    )
                )";
$count_result = mysqli_query($result, $count_query);
$total_unreturned = mysqli_fetch_assoc($count_result)['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Currently Issued Books</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
            background-color: rgb(0, 0, 139);
            text-align: center;
        }
        .container {
            width: 80%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        h1 {
            text-align: center;
            font-weight: bold;
            color: black;
            background-color: darkgray;
            padding: 10px;
            border-radius: 10px;
        }
        .search-bar {
            text-align: right;
            margin-bottom: 20px;
        }
        .search-bar input[type="text"] {
            padding: 12px;
            font-weight: bold;
            font-size: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 300px;
        }
        .search-bar input[type="submit"] {
            padding: 10px 14px;
            background: #007BFF;
            color: white;
            font-size: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 5px;
        }
        .search-bar input[type="submit"]:hover {
            background: #0056b3;
        }
        .summary {
            text-align: left;
            margin-bottom: 15px;
            font-weight: bold;
        }
        .no-results {
            color: #ff0000;
            font-weight: bold;
            padding: 10px;
        }
    </style>
</head>
<body>
<h1>LIBRARY MANAGEMENT SYSTEM</h1>
<div class="container">
    <!-- Search Bar -->
    <div class="search-bar">
        <form action="" method="GET">
            <input type="text" name="search" placeholder="Search by username, regno, or book name" value="<?php echo htmlspecialchars($search); ?>">
            <input type="submit" value="Search">
            <?php if($search): ?>
                <a href="issuelist.php" style="margin-left: 10px;">Clear Search</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="summary">
        Total Unreturned Books: <?php echo $total_unreturned; ?>
    </div>

    <h2 style="font-size:26px;">Currently Issued Books (Not Returned)</h2>

    <table>
        <thead>
            <tr>
                <th>Issue ID</th>
                <th>Reg No</th>
                <th>Username</th>
                <th>Book Name</th>
                <th>Author</th>
                <th>Pages</th>
                <th>Year</th>
                <th>Issue Date</th>
                <th>Days Issued</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($resul) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($resul)): ?>
                    <?php
                    $issue_date = new DateTime($row['issuedate']);
                    $current_date = new DateTime();
                    $days_issued = $issue_date->diff($current_date)->days;
                    ?>
                    <tr>
                        <td><?php echo $row['issueid']; ?></td>
                        <td><?php echo $row['regno']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['bookname']; ?></td>
                        <td><?php echo $row['author']; ?></td>
                        <td><?php echo $row['no_of_pages']; ?></td>
                        <td><?php echo $row['year_of_publish']; ?></td>
                        <td><?php echo date('d-M-Y', strtotime($row['issuedate'])); ?></td>
                        <td><?php echo $days_issued; ?> days</td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9" class="no-results">No currently issued books found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>

<?php mysqli_close($result); ?>