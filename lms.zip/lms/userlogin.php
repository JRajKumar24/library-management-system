<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <style>
     
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
            position: relative;
            font-family: 'Arial', sans-serif;
        }

        img {
            height: 100vh;
            width: 100vw;
            object-fit: cover;
            opacity: 0.8;
            position: absolute;
            top: 0;
            left: 0;
            z-index: -1;
        }

        .title {
            text-align: center;
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.6);
            padding: 10px 20px;
            border-radius: 10px;
        }

        .nav {
            float: right;
            margin: 20px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 0 5px;
            border-radius: 5px;
            background-color: rgba(0, 0, 0, 0.5);
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .nav a:hover {
            background-color: rgba(0, 0, 0, 0.8);
            transform: translateY(-2px);
        }

        .login-header {
            text-align: center;
            color: white;
            background-color: rgba(0, 0, 0, 0.7);
            display: inline-block;
            padding: 10px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: absolute;
            top: 25%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        form {
            position: absolute;
            top: 60%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, cornflowerblue, deepskyblue);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            width: 300px;
            text-align: center;
        }

        form table {
            width: 100%;
        }

        form td {
            padding: 10px;
        }

        form label {
            color: white;
            font-weight: bold;
        }

        form input {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            margin-top: 5px;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        form input:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(255, 255, 255, 0.5);
        }

        .error {
            color: red;
            font-size: 0.8em;
            margin-top: 5px;
            display: none;
        }

        button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
            margin-top: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        button:hover {
            background: linear-gradient(135deg, #2575fc, #6a11cb);
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
        }

        button:active {
            transform: translateY(0);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>

  
    <img src="regbackground.jpg" alt="Library Image"><br>

    <div class="title">Library Management System</div>

    <div class="nav">
        <a href="homepage.php">Home</a>
        <a href="userregistration.php">New User?</a>
    </div>

    <h1 class="login-header">USER LOGIN</h1>
<br><br><br><br><br><br><br>

    <form action="userlogindb.php" onsubmit="return validateForm()" method="POST">
        <table>
            <tr>
                <td><label>RegisterNo.</label></td>
                <td>
                    <input type="text" id="regno" name="regno"placeholder="Enter your register number" oninput="validateRegNo()" required>
                    <div id="regno-error" class="error">Registration number must be 12 digits.</div>
                </td>
            </tr>
            <tr>
                <td><label>Password</label></td>
                <td>
                    <input type="password" id="password" name="password" placeholder="Enter your password" oninput="validatePassword()" required>
                    <div id="password-error" class="error">Password must be 8-16 characters.</div>
                </td>
            </tr>
        </table>
        <button type="submit">Login</button>
    </form>

    <script>
        // Validate Registration Number
        function validateRegNo() {
            const regno = document.getElementById('regno').value;
            const regnoError = document.getElementById('regno-error');
            const regex = /^\d{12}$/;

            if (!regex.test(regno)) {
                regnoError.style.display = 'block';
                return false;
            } else {
                regnoError.style.display = 'none';
                return true;
            }
        }

        // Validate Password
        function validatePassword() {
            const password = document.getElementById('password').value;
            const passwordError = document.getElementById('password-error');
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/; 

            if (!regex.test(password)) {
                passwordError.style.display = 'block';
                return false;
            } else {
                passwordError.style.display = 'none';
                return true;
            }
        }

        // Validate Form Before Submission
        function validateForm() {
            const isRegNoValid = validateRegNo();
            const isPasswordValid = validatePassword();

            return isRegNoValid && isPasswordValid;
        }
    </script>
</body>
</html>