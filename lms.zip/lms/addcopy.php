<?php
include 'config.php'; // Connection variable is $result

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $book_name = mysqli_real_escape_string($result, $_POST['book_name']);
    $author = mysqli_real_escape_string($result, $_POST['author']);
    $copies_to_add = (int)$_POST['copies_to_add'];
    
    // Server-side validation
    $error = '';
    if (!preg_match('/^[a-zA-Z0-9\s\-\.\']+$/', $book_name)) {
        $error = "Book name can only contain letters, numbers, spaces, hyphens, periods and apostrophes";
    } elseif (!preg_match('/^[a-zA-Z\s\-\.\']+$/', $author)) {
        $error = "Author name can only contain letters, spaces, hyphens, periods and apostrophes";
    } elseif ($copies_to_add <= 0) {
        $error = "Please enter a valid number of copies (greater than 0)";
    } else {
        // Check if book exists
        $check_book = mysqli_query($result, "SELECT * FROM books WHERE book_name = '$book_name' AND author = '$author'");
        if (mysqli_num_rows($check_book) == 0) {
            $error = "Book not found with the specified name and author";
        } else {
            // Get current copies count
            $book_data = mysqli_fetch_assoc($check_book);
            $current_copies = $book_data['no_of_copies'];
            
            // Update the number of copies
            $update_query = "UPDATE books SET no_of_copies = no_of_copies + $copies_to_add 
                            WHERE book_name = '$book_name' AND author = '$author'";
            if (mysqli_query($result, $update_query)) {
                // Show success message and redirect
                echo "<script>
                        alert('Successfully added $copies_to_add copies to \\'$book_name\\' (Total copies now: " . ($current_copies + $copies_to_add) . ")');
                        window.location.href = 'adminpage.php';
                      </script>";
                exit();
            } else {
                $error = "Error updating copies: " . mysqli_error($result);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
            position: relative;
            font-family: 'Arial', sans-serif;
        }

        img {
            height: 100vh;
            width: 100vw;
            object-fit: cover;
            opacity: 0.8;
            position: absolute;
            top: 0;
            left: 0;
            z-index: -1;
        }

        .title {
            text-align: center;
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.6);
            padding: 10px 20px;
            border-radius: 10px;
        }

        .nav {
            float: right;
            margin: 20px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 0 5px;
            border-radius: 5px;
            background-color: rgba(0, 0, 0, 0.5);
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .nav a:hover {
            background-color: rgba(0, 0, 0, 0.8);
            transform: translateY(-2px);
        }

        form {
            position: absolute;
            top: 50%; 
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: cornflowerblue;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 600px; 
            text-align: center;
        }

        form h1 {
            color: white;
            background-color: rgba(0, 0, 0, 0.7);
            padding: 10px 20px;
            border-radius: 10px;
            margin-top: 0;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        form table {
            width: 100%;
        }

        form td {
            padding: 10px;
            min-height: 70px; 
        }

        form label {
            color: white;
            font-weight: bold;
            text-align: right;
            display: inline-block;
            width: 120px;
            padding-right: 10px;
        }

        form input {
            width: calc(100% - 20px);
            padding: 8px;
            border: none;
            border-radius: 5px;
            margin-top: 5px;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        form input:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(255, 255, 255, 0.5);
        }

        .error {
            color: red;
            font-size: 0.8em;
            margin-top: 5px;
            display: none;
        }

        button {
            padding: 12px 20px; 
            border: none;
            border-radius: 5px;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
            margin-top: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            float: right; 
        }

        button:hover {
            background: linear-gradient(135deg, #2575fc, #6a11cb);
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
        }

        button:active {
            transform: translateY(0);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <img src="regbackground.jpg" alt="Library Image"><br>
    
    <div class="title">Library Management System</div>

    <div class="nav">
        <a href="adminpage.php" style="padding-right:15px;">Admin Home</a>
    </div>

    <form method="POST" onsubmit="return validateForm()">
        <h1>Add Book Copies</h1>
        <table>
            <tr>
                <td><label for="book_name">Book Name:</label></td>
                <td>
                    <input type="text" id="book_name" name="book_name" placeholder="Enter book name" 
                           oninput="validateBookName()" required>
                    <div id="book_name-error" class="error">Only letters, numbers, spaces, hyphens, periods and apostrophes allowed</div>
                </td>
            </tr>
            <tr>
                <td><label for="author">Author:</label></td>
                <td>
                    <input type="text" id="author" name="author" placeholder="Enter author name" 
                           oninput="validateAuthor()" required>
                    <div id="author-error" class="error">Only letters, spaces, hyphens, periods and apostrophes allowed</div>
                </td>
            </tr>
            <tr>
                <td><label for="copies_to_add">Copies to Add:</label></td>
                <td>
                    <input type="number" id="copies_to_add" name="copies_to_add" min="1" 
                           placeholder="Enter number of copies" oninput="validateCopies()" required>
                    <div id="copies-error" class="error">Must be greater than 0</div>
                </td>
            </tr>
        </table>
        <button type="submit">Add Copies</button>
    </form>

    <script>
        // Validation functions
        function validateBookName() {
            const input = document.getElementById('book_name');
            const error = document.getElementById('book_name-error');
            const regex = /^[a-zA-Z0-9\s\-\.']+$/;
            
            if (!regex.test(input.value)) {
                error.style.display = 'block';
                return false;
            } else {
                error.style.display = 'none';
                return true;
            }
        }
        
        function validateAuthor() {
            const input = document.getElementById('author');
            const error = document.getElementById('author-error');
            const regex = /^[a-zA-Z\s\-\.']+$/;
            
            if (!regex.test(input.value)) {
                error.style.display = 'block';
                return false;
            } else {
                error.style.display = 'none';
                return true;
            }
        }
        
        function validateCopies() {
            const input = document.getElementById('copies_to_add');
            const error = document.getElementById('copies-error');
            
            if (input.value <= 0) {
                error.style.display = 'block';
                return false;
            } else {
                error.style.display = 'none';
                return true;
            }
        }
        
        // Form validation
        function validateForm() {
            const isBookValid = validateBookName();
            const isAuthorValid = validateAuthor();
            const isCopiesValid = validateCopies();
            
            return isBookValid && isAuthorValid && isCopiesValid;
        }
        
        // Real-time validation
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('book_name').addEventListener('input', validateBookName);
            document.getElementById('author').addEventListener('input', validateAuthor);
            document.getElementById('copies_to_add').addEventListener('input', validateCopies);
        });
    </script>
</body>
</html>

<?php mysqli_close($result); ?>