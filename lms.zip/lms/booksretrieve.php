<?php
include 'config.php'; // Include database connection

// Check if a search query is provided
$search = isset($_GET['search']) ? $_GET['search'] : '';
$search_condition = $search ? "WHERE book_name LIKE '%$search%' OR author LIKE '%$search%'" : '';

// Fetch books with search condition
$query = "SELECT * FROM books $search_condition";
$resul = mysqli_query($result, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
            background-color: rgb(0, 0, 139);
            text-align: center;
        }
        .container {
            width: 80%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #007BFF;
            color: white;
        }
        h1 {
            text-align: center;
            font-weight: bold;
            color: black;
            background-color: darkgray;
            padding: 10px;
            border-radius: 10px;
        }
        .search-bar {
            text-align: right;
            margin-bottom: 20px;
        }
        .search-bar input[type="text"] {
            padding: 12px;
            font-weight: bold;
            font-size: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 200px;
        }
        .search-bar input[type="submit"] {
            padding: 10px 14px;
            background: #007BFF;
            color: white;
            font-size: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .search-bar input[type="submit"]:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
<h1>LIBRARY MANAGEMENT SYSTEM</h1>
<div class="container">
    <!-- Search Bar -->
    <div class="search-bar">
        <form action="" method="GET">
            <input type="text" name="search" placeholder="Search by book or author" value="<?php echo htmlspecialchars($search); ?>">
            <input type="submit" value="Search">
        </form>
    </div>

    <h2 style="font-size:26px;">Book List</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Book Name</th>
            <th>Author</th>
            <th>Pages</th>
            <th>Year</th>
            <th>Copies</th>
        </tr>

        <?php if (mysqli_num_rows($resul) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($resul)): ?>
                <tr>
                    <td><?php echo $row['book_id']; ?></td>
                    <td><?php echo $row['book_name']; ?></td>
                    <td><?php echo $row['author']; ?></td>
                    <td><?php echo $row['no_of_pages']; ?></td>
                    <td><?php echo $row['year_of_publish']; ?></td>
                    <td><?php echo $row['no_of_copies']; ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">No books found.</td>
            </tr>
        <?php endif; ?>
    </table>
</div>

</body>
</html>

<?php mysqli_close($result); ?>