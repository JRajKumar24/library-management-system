<?php
include('config.php'); // Include your database configuration file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $bookname = $_POST['bookname'];
    $author = $_POST['authorname'];

    // Perform the delete query
    $query = "DELETE FROM books WHERE book_name = '$bookname' AND author = '$author'";
    $resul= mysqli_query($result, $query); // Use $conn (or your connection variable) instead of $result

    if ($resul) {
        // Check if any rows were affected
        if (mysqli_affected_rows($result) > 0) {
            echo "<script>alert('Book deleted successfully!'); window.location.href = 'adminpage.php';</script>";
        } else {
            echo "<script>alert('No matching book found.'); window.location.href = 'adminpage.php';</script>";
        }
    } 
}
?>