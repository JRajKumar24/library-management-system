<?php
include('config.php'); // Include database connection

$regno = $_GET['regno'];
$bookname = $_GET['bookname'];

// Query to check if the regno and bookname exist in the issue table
$query = "SELECT issuedate FROM issue WHERE regno = '$regno' AND bookname = '$bookname'";
$resul = mysqli_query($result, $query);

if ($resul && mysqli_num_rows($resul) > 0) {
    $row = mysqli_fetch_assoc($resul);
    echo json_encode(['status' => 'success', 'issuedate' => $row['issuedate']]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No record found for the given Reg No and Book Name.']);
}
?>