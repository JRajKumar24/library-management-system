<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remove Book</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #ff9a9e, #fad0c4); /* Gradient background */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        h1 {
            text-align: center;
            font-size: 2.5em; /* Larger font size */
            color: #ffffff; /* White text */
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3); /* Text shadow for better visibility */
            margin-bottom: 20px;
        }
        .form-container {
            background: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            padding: 25px;
            border-radius: 15px; /* Rounded corners */
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2); /* Subtle shadow */
            width: 350px; /* Slightly wider form */
            text-align: center;
        }
        .form-container h2 {
            margin-bottom: 20px;
            font-size: 1.8em; /* Larger font size */
            color: #00796b; /* Dark teal */
        }
        .form-group {
            margin-bottom: 20px; /* Increased spacing */
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px; /* Increased spacing */
            font-weight: bold;
            color: #555;
            font-size: 16px; /* Larger font size */
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px; /* Rounded corners */
            font-size: 16px; /* Larger font size */
            box-sizing: border-box;
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        .form-group input:focus {
            border-color: #00796b; /* Dark teal */
            outline: none;
            box-shadow: 0 0 8px rgba(0, 121, 107, 0.5); /* Focus shadow */
        }
        .remove-button {
            background-color: #ff4d4d; /* Red */
            color: white;
            border: none;
            padding: 12px 24px; /* Larger padding */
            border-radius: 8px; /* Rounded corners */
            font-size: 16px; /* Larger font size */
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
            width: 100%; /* Full-width button */
            margin-top: 10px;
        }
        .remove-button:hover {
            background-color: #cc0000; /* Darker red */
            transform: scale(1.05); /* Slight scale effect on hover */
        }
        .remove-button:active {
            transform: scale(0.95); /* Slight scale effect on click */
        }
        .error {
            color: red;
            font-size: 0.9rem;
            margin-top: 5px;
            display: none;
        }
    </style>
</head>
<body>
    <div>
        <h1>Library Management System</h1>
        <div class="form-container">
            <h2>Remove Book</h2>
            <form action="removebookdb.php" method="POST"onsubmit="return validateForm()">
                <div class="form-group">
                    <label for="bookname">Book Name</label>
                    <input type="text" id="bookname" name="bookname" placeholder="Enter book name" oninput="validateBookName()" required>
                    <div class="error" id="booknameError">Book name must contain only letters or letters with digits.</div>
                </div>
                <div class="form-group">
                    <label for="authorname">Author Name</label>
                    <input type="text" id="authorname" name="authorname" placeholder="Enter author name" oninput="validateAuthorName()" required>
                    <div class="error" id="authornameError">Author name must contain only letters.</div>
                </div>
                <button type="submit" class="remove-button">Remove Book</button>
            </form>
        </div>
    </div>

    <script>
        // Function to validate Book Name
        function validateBookName() {
            const bookName = document.getElementById('bookname').value.trim();
            const bookNameError = document.getElementById('booknameError');
            if (!/^[A-Za-z0-9 ]+$/.test(bookName)) {
                bookNameError.style.display = 'block';
                return false;
            } else {
                bookNameError.style.display = 'none';
                return true;
            }
        }

        // Function to validate Author Name
        function validateAuthorName() {
            const authorName = document.getElementById('authorname').value.trim();
            const authorNameError = document.getElementById('authornameError');
            if (!/^[A-Za-z ]+$/.test(authorName)) {
                authorNameError.style.display = 'block';
                return false;
            } else {
                authorNameError.style.display = 'none';
                return true;
            }
        }

        // Function to validate the entire form
        function validateForm() {
            const isBookNameValid = validateBookName();
            const isAuthorNameValid = validateAuthorName();

            // If all validations pass, return true (allow form submission)
            if (isBookNameValid && isAuthorNameValid) {
                return true;
            } else {
                alert("Please correct the errors before submitting.");
                return false; // Prevent form submission
            }
        }
    </script>
</body>
</html>