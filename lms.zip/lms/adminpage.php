<!doctype html>
<html>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        
        h1 {
            text-align: center;
            color: white;
            background-color: #333;
            padding: 6px;
            margin: 0;
            font-size: 2.5em;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        
        .links {
            display: flex;
            justify-content: space-between;
            padding: 6px;
            background: #444;
            border-radius: 10px;
            margin: 10px;
           
        }
        
        .links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 8px 10px;
            border-radius: 8px;
            font-size: 1.2em;
        }
        
        .links a:hover {
            background: #555;
            color: white;
            transform: scale(1.1);
        }
        
        .leftside, .rightside {
            display: flex;
            gap: 20px; 
        }

        table {
            background-color: #555; 
            border-radius: 15px; 
             
            margin: 10px auto;
            width: 40%;
            padding: 10px;
        }
        
        td {
            padding: 20px; 
            text-align: center; 
        }
        
        button {
            background-color: #007BFF; 
            color: white; 
            border: none; 
            padding: 10px 20px; 
            border-radius: 10px; 
            font-size: 1.2em; 
            font-weight: bold; 
            cursor: pointer; 
                        
        }

        button:hover {
            background-color:rgb(0, 179, 21); 
            transform: scale(1.1);
        }

        #history {
            float: right;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.2em;
            color:rgb(51, 0, 255);
            border-radius: 10px;
            
        }

        #history:hover {
            background-color:rgb(0, 149, 255);
            color: white;
        }


        /* Slide-down animation */
        @keyframes slideDown {
            from {
                top: -50px;
            }
            to {
                top: 0;
            }
        }
       
        /* Fade-out animation */
        @keyframes fadeOut {
            from {
                opacity: 1;
            }
            to {
                opacity: 0;
            }
        }
    </style>
    <body>
        <div>
            <center><h1>LIBRARY MANAGEMENT SYSTEM</h1></center>
            <div class="links">
                <div class="leftside">
                    <a href="issuelist.php">Issue List</a>
                    <a href="returnlist.php">Return List</a>
                </div>
                <div class="rightside">
                    <a href="homepage.php">Home</a>
                    <a href="booksretrieve.php">Books List</a>
                    <a href="userlist.php">User List</a>
                </div>
            </div>
        </div>
        <br><br>
        <table>
            <tr>
                <td><a href="issuebook.php"><button>Issue</button></a></td>
                <td><a href="addbook.php"><button>Add Book</button></a></td>
            </tr>
            <tr>
                <td><a href="removeuser.php"><button>Remove User</button></a></td>
                <td><a href="removebook.php"><button>Remove Book</button></a></td>
            </tr>
            <tr>
                <td><a href="addcopy.php"><button>Add Copy</button></a></td>
                <td><a href="returnbook.php"><button>Return Book</button></a></td>
            </tr>
        </table>
        <br><br>
        <a href="bookissuehistory.php" id="history">Book Issue History</a>

    </body>
</html>