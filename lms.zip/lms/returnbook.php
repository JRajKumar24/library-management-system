<!DOCTYPE html>
<html>

<head>
    <title>Return Book</title>
    <style>
        /* Full-screen background */
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
        }

        /* Page title */
        .page-title {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #fff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        /* Form container */
        .form-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            width: 800px;
            text-align: center;
        }

        /* Form title */
        .form-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #333;
        }

        /* Form content */
        .form-content {
            display: flex;
            gap: 20px;
        }

        /* Left and right sections */
        .form-section {
            flex: 1;
            text-align: left;
        }

        /* Form fields */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 16px;
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
        }

        .form-group input[readonly] {
            background-color: #f0f0f0;
        }

        /* Calculate button */
        .calculate-btn {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-left: 10px;
        }

        .calculate-btn:hover {
            background-color: #cc0000;
        }

        /* Submit button */
        .submit-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            float: right;
            margin-top: 20px;
        }

        .submit-btn:hover {
            background-color: #45a049;
        }

        /* Error messages */
        .error {
            color: #ff4d4d;
            font-size: 14px;
            margin-top: 5px;
            display: none;
        }
    </style>
</head>

<body>
    <!-- Page title -->
    <div class="page-title">LIBRARY MANAGEMENT SYSTEM</div>

    <!-- Form container -->
    <div class="form-container">
        <!-- Form title -->
        <div class="form-title">Return Book</div>

        <!-- Form content -->
        <div class="form-content">
            <!-- Left section -->
            <div class="form-section">
                <!-- Registration Number -->
                <div class="form-group">
                    <label for="regno">Registration Number (Reg No):</label>
                    <input type="text" id="regno" oninput="validateRegNo()">
                    <div id="regno-error" class="error">Registration number must be exactly 12 digits.</div>
                </div>

                <!-- Book Name -->
                <div class="form-group">
                    <label for="bookname">Book Name:</label>
                    <input type="text" id="bookname" oninput="validateBookName()">
                    <div id="bookname-error" class="error">Book name must contain letters only or letters with digits and spaces (not digits only).</div>
                </div>

                <!-- Return Date -->
                <div class="form-group">
                    <label for="returndate">Return Date:</label>
                    <input type="date" id="returndate">
                </div>
            </div>

            <!-- Right section -->
            <div class="form-section">
                <!-- Overdue Fine -->
                <div class="form-group">
                    <label for="overduefine">Overdue Fine:</label>
                    <div style="display: flex; align-items: center;">
                        <input type="text" name="overduefine" id="overduefine" readonly style="flex: 1;">
                        <button type="button" class="calculate-btn" onclick="calculateOverdueFine()">Calculate Fine</button>
                    </div>
                </div>

                <!-- Book Damage Fine -->
                <div class="form-group">
                    <label for="bookdamagefine">Book Damage Fine:</label>
                    <input type="number" name="bookdamagefine" id="bookdamagefine" oninput="updateTotalFine()">
                </div>

                <!-- Total Fine -->
                <div class="form-group">
                    <label for="totalfine">Total Fine:</label>
                    <input type="text" name="totalfine" id="totalfine" readonly>
                </div>
            </div>
        </div>

        <!-- Submit button -->
        <button type="button" class="submit-btn" onclick="submitForm()">Add Submission</button>
    </div>

    <script>
        // Validate Registration Number (must be 12 digits)
        function validateRegNo() {
            const regno = document.getElementById('regno').value;
            const regnoError = document.getElementById('regno-error');
            const regnoPattern = /^\d{12}$/;

            if (!regnoPattern.test(regno)) {
                regnoError.style.display = 'block';
                return false;
            } else {
                regnoError.style.display = 'none';
                return true;
            }
        }

        // Validate Book Name (must contain letters only or letters with digits and spaces, not digits only)
        function validateBookName() {
            const bookname = document.getElementById('bookname').value;
            const booknameError = document.getElementById('bookname-error');
            const booknamePattern = /^(?=.*[a-zA-Z])[a-zA-Z0-9\s]*$/;

            if (!booknamePattern.test(bookname)) {
                booknameError.style.display = 'block';
                return false;
            } else {
                booknameError.style.display = 'none';
                return true;
            }
        }

        // Validate all fields before submission
        function validateForm() {
            const isRegNoValid = validateRegNo();
            const isBookNameValid = validateBookName();

            return isRegNoValid && isBookNameValid;
        }

        async function calculateOverdueFine() {
            // Fetch input values
            const regno = document.getElementById('regno').value;
            const bookname = document.getElementById('bookname').value;
            const returndate = document.getElementById('returndate').value;

            // Validate inputs
            if (!regno || !bookname || !returndate) {
                alert('Please fill in all fields.');
                return;
            }

            // Fetch issuedate from the issue table
            const response = await fetch(`fetch_issuedate.php?regno=${regno}&bookname=${bookname}`);
            const data = await response.json();

            if (data.status === 'error') {
                alert(data.message);
                return;
            }

            const issuedate = data.issuedate;

            // Calculate the number of days between issuedate and returndate
            const issueDateObj = new Date(issuedate);
            const returnDateObj = new Date(returndate);
            const timeDiff = returnDateObj - issueDateObj;
            const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24)); // Convert milliseconds to days

            // Calculate overdue fine (₹10 per day after 15 days)
            let overduefine = 0;
            if (daysDiff > 15) {
                overduefine = (daysDiff - 15) * 10; // Fine starts from the 16th day
            }
            document.getElementById('overduefine').value = overduefine;

            // Update total fine dynamically
            updateTotalFine();
        }

        function updateTotalFine() {
            // Fetch overdue fine and book damage fine
            const overduefine = parseFloat(document.getElementById('overduefine').value) || 0;
            const bookdamagefine = parseFloat(document.getElementById('bookdamagefine').value) || 0;

            // Calculate total fine
            const totalfine = overduefine + bookdamagefine;
            document.getElementById('totalfine').value = totalfine;
        }

        async function submitForm() {
            // Validate form before submission
            if (!validateForm()) {
                alert('Please correct the errors in the form.');
                return;
            }

            // Fetch input values
            const regno = document.getElementById('regno').value;
            const bookname = document.getElementById('bookname').value;
            const returndate = document.getElementById('returndate').value;
            const overduefine = document.getElementById('overduefine').value;
            const bookdamagefine = document.getElementById('bookdamagefine').value;
            const totalfine = document.getElementById('totalfine').value;

            // Validate inputs
            if (!regno || !bookname || !returndate || !overduefine || !bookdamagefine || !totalfine) {
                alert('Please fill in all fields and calculate the overdue fine.');
                return;
            }

            // Prepare data to send
            const formData = new FormData();
            formData.append('regno', regno);
            formData.append('bookname', bookname);
            formData.append('returndate', returndate);
            formData.append('overduefine', overduefine);
            formData.append('bookdamagefine', bookdamagefine);
            formData.append('totalfine', totalfine);

            // Send data to returnbookdb.php
            const response = await fetch('returnbookdb.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.text();
            console.log('Server Response:', result); // Debugging

            if (result.trim() === 'success') { // Use trim() to remove extra spaces
                alert('Book returned successfully!');
                window.location.href = 'adminpage.php'; // Redirect to adminpage.php
            } else {
                alert('Error: ' + result);
            }
        }
    </script>
</body>

</html>