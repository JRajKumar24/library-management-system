<?php
include("config.php");

// Retrieve form data
$regno = $_POST['regno'];
$bookname = $_POST['bookname'];
$issuedate = $_POST['issuedate'];

// Check if the user exists in the registration table
$userExistsQuery = mysqli_query($result, "SELECT * FROM registration WHERE regno='$regno'");
if (mysqli_num_rows($userExistsQuery) == 0) {
    echo "<script>alert('User does not exist'); window.location.href = 'adminpage.php';</script>";
    exit; // Stop further execution
}

// Check if the user has any unreturned books
$unreturnedQuery = mysqli_query($result, "
    SELECT i.issueid 
    FROM issue i
    LEFT JOIN returnbook r ON i.regno = r.regno AND i.bookname = r.bookname
    WHERE i.regno = '$regno' AND r.returnid IS NULL
");

if (mysqli_num_rows($unreturnedQuery) > 0) {
    echo "<script>alert('User has unreturned books and cannot borrow new ones'); window.location.href = 'adminpage.php';</script>";
    exit;
}

// Check if the book exists in the books table
$bookCheckQuery = mysqli_query($result, "SELECT * FROM books WHERE book_name='$bookname'");
if (mysqli_num_rows($bookCheckQuery) == 0) {
    echo "<script>alert('Book does not exist'); window.location.href = 'adminpage.php';</script>";
    exit; // Stop further execution
}

// Check if there are available copies of the book
$bookCopiesQuery = mysqli_query($result, "SELECT no_of_copies FROM books WHERE book_name='$bookname'");
$bookCopiesRow = mysqli_fetch_assoc($bookCopiesQuery);
$noOfCopies = $bookCopiesRow['no_of_copies'];

if ($noOfCopies <= 0) {
    echo "<script>alert('No copies available'); window.location.href = 'adminpage.php';</script>";
    exit; // Stop further execution
}

// Insert the issue record into the database
$insertQuery = mysqli_query($result, "INSERT INTO issue (regno, bookname, issuedate) VALUES ('$regno', '$bookname', '$issuedate')");
if ($insertQuery) {
    // Reduce the number of copies by 1 in the books table
    $updateQuery = mysqli_query($result, "UPDATE books SET no_of_copies = no_of_copies - 1 WHERE book_name='$bookname'");
    if ($updateQuery) {
        echo "<script>alert('Book issued successfully'); window.location.href = 'adminpage.php';</script>";
    } else {
        echo "<script>alert('Error updating book copies'); window.location.href = 'adminpage.php';</script>";
    }
} else {
    echo "<script>alert('Error issuing book'); window.location.href = 'adminpage.php';</script>";
}
?>