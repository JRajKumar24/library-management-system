
<?php

$a='localhost';
$b='root';
$c='';
$d='library';

$result=mysqli_connect($a,$b,$c,$d,3307);
?>