<?php
include 'config.php'; // Include database connection

// Check if a search query is provided
$search = isset($_GET['search']) ? $_GET['search'] : '';
$search_condition = $search ? "AND (r.username LIKE '%$search%' OR i.regno LIKE '%$search%' OR i.bookname LIKE '%$search%')" : '';

// Fetch all issued books with return status, date, and fine details
$issued_query = "SELECT i.issueid, i.regno, r.username, i.bookname, i.issuedate, 
                 b.author, b.no_of_pages, b.year_of_publish,
                 CASE 
                    WHEN EXISTS (
                        SELECT 1 FROM returnbook rb 
                        WHERE rb.regno = i.regno 
                        AND rb.bookname = i.bookname
                        AND rb.returndate >= i.issuedate
                        AND (
                            NOT EXISTS (
                                SELECT 1 FROM issue i2 
                                WHERE i2.regno = i.regno 
                                AND i2.bookname = i.bookname 
                                AND i2.issuedate > i.issuedate
                            )
                            OR rb.returndate < (
                                SELECT MIN(issuedate) FROM issue i3 
                                WHERE i3.regno = i.regno 
                                AND i3.bookname = i.bookname 
                                AND i3.issuedate > i.issuedate
                            )
                        )
                    ) THEN 'Returned'
                    ELSE 'Not Returned'
                 END AS status,
                 COALESCE(
                    (SELECT rb.returndate 
                     FROM returnbook rb 
                     WHERE rb.regno = i.regno 
                     AND rb.bookname = i.bookname
                     AND rb.returndate >= i.issuedate
                     AND (
                         NOT EXISTS (
                             SELECT 1 FROM issue i2 
                             WHERE i2.regno = i.regno 
                             AND i2.bookname = i.bookname 
                             AND i2.issuedate > i.issuedate
                         )
                         OR rb.returndate < (
                             SELECT MIN(issuedate) FROM issue i3 
                             WHERE i3.regno = i.regno 
                             AND i3.bookname = i.bookname 
                             AND i3.issuedate > i.issuedate
                         )
                     )
                     LIMIT 1), 
                    '-'
                 ) AS returndate,
                 COALESCE(
                    (SELECT rb.overduefine 
                     FROM returnbook rb 
                     WHERE rb.regno = i.regno 
                     AND rb.bookname = i.bookname
                     AND rb.returndate >= i.issuedate
                     AND (
                         NOT EXISTS (
                             SELECT 1 FROM issue i2 
                             WHERE i2.regno = i.regno 
                             AND i2.bookname = i.bookname 
                             AND i2.issuedate > i.issuedate
                         )
                         OR rb.returndate < (
                             SELECT MIN(issuedate) FROM issue i3 
                             WHERE i3.regno = i.regno 
                             AND i3.bookname = i.bookname 
                             AND i3.issuedate > i.issuedate
                         )
                     )
                     LIMIT 1), 
                    '-'
                 ) AS overduefine,
                 COALESCE(
                    (SELECT rb.bookdamagefine 
                     FROM returnbook rb 
                     WHERE rb.regno = i.regno 
                     AND rb.bookname = i.bookname
                     AND rb.returndate >= i.issuedate
                     AND (
                         NOT EXISTS (
                             SELECT 1 FROM issue i2 
                             WHERE i2.regno = i.regno 
                             AND i2.bookname = i.bookname 
                             AND i2.issuedate > i.issuedate
                         )
                         OR rb.returndate < (
                             SELECT MIN(issuedate) FROM issue i3 
                             WHERE i3.regno = i.regno 
                             AND i3.bookname = i.bookname 
                             AND i3.issuedate > i.issuedate
                         )
                     )
                     LIMIT 1), 
                    '-'
                 ) AS bookdamagefine,
                 COALESCE(
                    (SELECT rb.totalfine 
                     FROM returnbook rb 
                     WHERE rb.regno = i.regno 
                     AND rb.bookname = i.bookname
                     AND rb.returndate >= i.issuedate
                     AND (
                         NOT EXISTS (
                             SELECT 1 FROM issue i2 
                             WHERE i2.regno = i.regno 
                             AND i2.bookname = i.bookname 
                             AND i2.issuedate > i.issuedate
                         )
                         OR rb.returndate < (
                             SELECT MIN(issuedate) FROM issue i3 
                             WHERE i3.regno = i.regno 
                             AND i3.bookname = i.bookname 
                             AND i3.issuedate > i.issuedate
                         )
                     )
                     LIMIT 1), 
                    '-'
                 ) AS totalfine
          FROM issue i
          JOIN registration r ON i.regno = r.regno
          JOIN books b ON i.bookname = b.book_name
          WHERE 1=1 $search_condition
          ORDER BY i.issuedate DESC";
$issued_result = mysqli_query($result, $issued_query);

// Count totals
$total_issued = mysqli_num_rows($issued_result);
$total_returned = 0;
$total_unreturned = 0;

// Prepare data for display
$issued_books = [];
while ($row = mysqli_fetch_assoc($issued_result)) {
    $issued_books[] = $row;
    if ($row['status'] == 'Returned') {
        $total_returned++;
    } else {
        $total_unreturned++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Issued Books</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
            background-color: rgb(0, 0, 139);
            text-align: center;
        }
        .container {
            width: 90%; /* Increased from 80% to 90% */
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            table-layout: auto; /* Allows columns to adjust based on content */
        }
        th, td {
            padding: 12px; /* Slightly increased padding */
            border: 1px solid #ddd;
            text-align: left;
            white-space: nowrap; /* Prevent text wrapping */
        }
        th {
            background: #007BFF;
            color: white;
            position: sticky;
            top: 0;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        h1 {
            text-align: center;
            font-weight: bold;
            color: black;
            background-color: darkgray;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .search-bar {
            text-align: right;
            margin-bottom: 20px;
        }
        .search-bar input[type="text"] {
            padding: 12px;
            font-weight: bold;
            font-size: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 300px;
        }
        .search-bar input[type="submit"] {
            padding: 10px 14px;
            background: #007BFF;
            color: white;
            font-size: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 5px;
        }
        .search-bar input[type="submit"]:hover {
            background: #0056b3;
        }
        .summary {
            text-align: left;
            margin-bottom: 15px;
            font-weight: bold;
            font-size: 14px;
        }
        .no-results {
            color: #ff0000;
            font-weight: bold;
            padding: 10px;
        }
        .status-returned {
            color: green;
            font-weight: bold;
        }
        .status-not-returned {
            color: red;
            font-weight: bold;
        }
        .fine-amount {
            text-align: right;
            font-family: monospace;
            min-width: 80px; /* Minimum width for fine columns */
        }
        /* Specific column widths */
        .col-issueid { width: 80px; }
        .col-regno { width: 120px; }
        .col-username { width: 150px; }
        .col-bookname { width: 180px; }
        .col-author { width: 150px; }
        .col-date { width: 100px; }
        .col-status { width: 100px; }
    </style>
</head>
<body>
<h1>LIBRARY MANAGEMENT SYSTEM</h1>
<div class="container">
    <!-- Search Bar -->
    <div class="search-bar">
        <form action="" method="GET">
            <input type="text" name="search" placeholder="Search by username, regno, or book name" value="<?php echo htmlspecialchars($search); ?>">
            <input type="submit" value="Search">
            <?php if($search): ?>
                <a href="issuelist.php" style="margin-left: 10px;">Clear Search</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="summary">
        Total Issued Books: <?php echo $total_issued; ?> | 
        Returned: <span class="status-returned"><?php echo $total_returned; ?></span> | 
        Not Returned: <span class="status-not-returned"><?php echo $total_unreturned; ?></span>
    </div>

    <h2 style="font-size:26px;">All Issued Books with Fine Details</h2>

    <div style="overflow-x: auto;"> <!-- Added horizontal scroll for smaller screens -->
        <table>
            <thead>
                <tr>
                    <th class="col-issueid">Issue ID</th>
                    <th class="col-regno">Reg No</th>
                    <th class="col-username">Username</th>
                    <th class="col-bookname">Book Name</th>
                    <th class="col-author">Author</th>
                    <th class="col-date">Issue Date</th>
                    <th class="col-date">Return Date</th>
                    <th>Overdue Fine</th>
                    <th>Damage Fine</th>
                    <th>Total Fine</th>
                    <th class="col-status">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($issued_books) > 0): ?>
                    <?php foreach ($issued_books as $row): ?>
                        <tr>
                            <td><?php echo $row['issueid']; ?></td>
                            <td><?php echo $row['regno']; ?></td>
                            <td><?php echo $row['username']; ?></td>
                            <td><?php echo $row['bookname']; ?></td>
                            <td><?php echo $row['author']; ?></td>
                            <td><?php echo date('d-M-Y', strtotime($row['issuedate'])); ?></td>
                            <td><?php echo ($row['returndate'] != '-') ? date('d-M-Y', strtotime($row['returndate'])) : '-'; ?></td>
                            <td class="fine-amount"><?php echo ($row['overduefine'] != '-') ? '₹' . $row['overduefine'] : '-'; ?></td>
                            <td class="fine-amount"><?php echo ($row['bookdamagefine'] != '-') ? '₹' . $row['bookdamagefine'] : '-'; ?></td>
                            <td class="fine-amount"><?php echo ($row['totalfine'] != '-') ? '₹' . $row['totalfine'] : '-'; ?></td>
                            <td class="<?php echo $row['status'] == 'Returned' ? 'status-returned' : 'status-not-returned'; ?>">
                                <?php echo $row['status']; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11" class="no-results">No issued books found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>

<?php mysqli_close($result); ?>